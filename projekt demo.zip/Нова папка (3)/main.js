import { polish, polishOne, polishTwo } from "./pol.js";
import { english, englishOne, englishTwo } from "./eng.js";
import { programming } from "./exceptions.js";
function check(word) {
    // ===== settings =====
    const THRESHOLD = 0.01;           // звичайні слова: мінімальний середній score
    const MAX_UNKNOWN = 0.2;            // звичайні слова: жодної невідомої триграми
    const LENIENT_THRESHOLD = 0.002;  // слова, схожі на винятки: м'якший поріг
    const LENIENT_MAX_UNKNOWN = 0.5;  // слова, схожі на винятки: до 50 % невідомих
    const EXCEPTION_FREQ = 0.05;      // частота, яку отримує триграма з винятків
    if (!check.cache) {
        const freq = new Map();
        for (const item of english) freq.set(item.trigram, item.freq);
        for (const item of polish) {
            freq.set(item.trigram, Math.max(item.freq, freq.get(item.trigram) || 0));
        }
        const excTrigrams = new Set();
        for (const w of programming) {
            const W = w.toUpperCase();
            for (let i = 0; i < W.length - 2; i++) excTrigrams.add(W.substring(i, i + 3));
        }
        const short = new Set([
            ...polishOne, ...polishTwo, ...englishOne, ...englishTwo,
            ...programming.map(w => w.toUpperCase()).filter(w => w.length < 3)
        ]);
        check.cache = { freq, excTrigrams, short };
    }
    const { freq, excTrigrams, short } = check.cache;
    word = word.toUpperCase();
    if (word.length < 3) {
        return short.has(word);
    }
    let score = 0;
    let unknown = 0;  
    let fromExc = 0;  
    let count = 0;
    for (let i = 0; i < word.length - 2; i++) {
        const trigram = word.substring(i, i + 3);
        let f = freq.get(trigram) || 0;
        if (excTrigrams.has(trigram)) {
            fromExc++;
            f = Math.max(f, EXCEPTION_FREQ);
        }
        if (f === 0) unknown++;
        score += f;
        count++;
    }
    score /= count;
    const lenient = fromExc / count >= 0.5;
    const threshold = lenient ? LENIENT_THRESHOLD : THRESHOLD;
    const maxUnknown = lenient ? LENIENT_MAX_UNKNOWN : MAX_UNKNOWN;
    if (unknown / count > maxUnknown) {
        return false;
    }
    return score >= threshold;
}
function splitext(text) {
    let TempMemory = [];
    let splited = text.split(" ");
    for (let i = 0; i < splited.length; i++) {
        if (check(splited[i])) {
            TempMemory.push(splited[i]);
        }
    }
    return TempMemory.join(" ");
}
let inputext = "";
let FinalResult = splitext(inputext).split(".");
console.log(FinalResult);