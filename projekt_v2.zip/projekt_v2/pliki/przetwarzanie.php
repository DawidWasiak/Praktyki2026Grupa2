<?php
set_time_limit(900);
header("Content-Type: application/json; charset=utf-8");
function respond($data, $status = 200) {
    http_response_code($status);
    echo json_encode(
        $data,
        JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
    );
    exit;
}
// Odczyt danych z JavaScript
$input = file_get_contents("php://input");
$data = json_decode($input, true);
if (
    !is_array($data) ||
    !isset($data["sentences"]) ||
    !is_array($data["sentences"])
) {
    respond([
        "success" => false,
        "error" => "Nieprawidłowe dane wejściowe"
    ], 400);
}

// 2. Zachowujemy oryginalne zdania
$sentences = array_values(array_filter(
    $data["sentences"],
    fn($s) => is_string($s) && trim($s) !== ""
));
$text = implode("\n", $sentences);

if (trim($text) === "") {
    respond([
        "success" => false,
        "error" => "Brak tekstu do analizy"
    ], 400);
}
// Instrukcje dla modelu (jeden punkt obrad na raz)
$systemPrompt = <<<'PROMPT'
Jesteś protokolantem spotkania. Dostajesz fragment surowego stenogramu
rozpoznanego automatycznie z mowy (ASR). Fragment dotyczy JEDNEGO punktu obrad.
Zrób z niego zwięzłe podsumowanie ustaleń do protokołu.

Zasady:
1. Pisz wyłącznie po polsku, w trzeciej osobie, w czasie przeszłym.
   Nigdy nie pisz "mamy", "nasz", "proponuję".
2. Osobę prowadzącą nazywaj dokładnie tak, jak podano w linii
   "Prowadzący spotkanie:". Inne osoby rozpoznawaj po zdaniach typu
   "Udzielam głosu doktorowi Nowakowi" i zapisuj w mianowniku, z tytułem, jeśli
   pada (np. "dr Nowak", "mgr Wójcik", "inż. Zieliński"). Imiona i nazwiska
   przepisuj dokładnie. Nie wymyślaj osób.
3. Jeden wpis = jedna wypowiedź jednej osoby w 1-2 zdaniach: co przedstawiła,
   zaproponowała, zadeklarowała lub do czego kogoś zobowiązała. Zachowaj liczby,
   kwoty, terminy i osoby odpowiedzialne.
4. Gdy prowadzący mówi do kogoś "proszę przygotować / przesłać / zrobić ...",
   zapisz to jako wpis prowadzącego: "Zobowiązał mgr. X do ... do <termin>."
5. Pomijaj puste formułki ("Dziękuję", "Udzielam głosu ...", "Przejdziemy teraz do ...").
6. Popraw błędy rozpoznawania mowy na podstawie kontekstu (słowa, które brzmią
   podobnie, ale nie pasują do zdania), np. "korkus" -> "konkurs",
   "pasterz uczelni" -> "prestiż uczelni", "gimnastyka" -> "informatyka",
   "antybiotyki i automatyka" -> "robotyka i automatyka",
   "zastój / zastęp trzech osób" -> "zespół trzech osób",
   "nauk śliskich" -> "nauk ścisłych", "powiódł zespół" -> "powołał zespół".
   Przed napisaniem wpisu sprawdź każde słowo: jeśli nie pasuje do tematu
   spotkania, zastąp je podobnie brzmiącym słowem, które ma sens.
   Popraw też tytuł punktu, jeśli ma taki błąd. Nie zmieniaj sensu.
7. Każdy wpis musi mieć wypełnione pole "speaker".
8. Gdy ktoś sam mówi "zobowiązuję się", "zajmę się", "mogę przygotować",
   to jego własna deklaracja: zapisz ją jako jego wpis ("Zadeklarował ...").
   Nie zamieniaj tego na zobowiązanie wydane przez prowadzącego.
9. Nie przepisuj zdań ze stenogramu dosłownie — zawsze je streszczaj.
10. Kto mówi: po zdaniu "Udzielam głosu X" kolejna wypowiedź należy do X.
   Gdy X skończy, prowadzący zwykle mówi "Dziękuję ..." i dalej mówi prowadzący,
   aż znowu komuś udzieli głosu.

Zwróć WYŁĄCZNIE poprawny JSON w tym formacie:
{
  "title": "tytuł punktu",
  "entries": [
    { "speaker": "Dyrektor", "text": "Otworzył posiedzenie i przedstawił porządek obrad." }
  ]
}
Nie dodawaj komentarzy ani tekstu poza JSON-em.
PROMPT;

// Przykład dla modelu: jak wygląda dobry wynik dla jednego punktu
const EXAMPLE_INPUT = <<<'TXT'
Prowadzący spotkanie: Prowadzący
Tytuł punktu: Informacje o finansowaniu

Fragment stenogramu:
Przejdziemy teraz do Informacje o finansowaniu. Udzielam głosu panu profesorowi Kowalskiemu.
Dziękuję za udzielenie głosu. Środki z subwencji nie pokrywają nawet kosztów utrzymania aparatury. Jeśli nie znajdziemy innych źródeł, nasz rozbój naukowy zostanie zahamowany.
Dziękuję panu profesorowi. Udzielam głosu doktorowi Nowakowi.
Dziękuję bardzo. Proponuję udział w krajowym korkusie grantowym, maksymalna kwota to pięć milionów złotych, wniosek trzeba złożyć do końca przyszłego miesiąca.
To brzmi obiecująco. Panie doktorze, proszę przesłać pełne informacje o konkursie na mój adres mailowy do końca dnia.
TXT;
const EXAMPLE_OUTPUT = <<<'TXT'
{
  "title": "Informacje o finansowaniu",
  "entries": [
    { "speaker": "prof. Kowalski", "text": "Przedstawił niedostateczne finansowanie jednostki: środki z subwencji nie pokrywają kosztów utrzymania aparatury, a bez nowych źródeł rozwój naukowy zostanie zahamowany." },
    { "speaker": "dr Nowak", "text": "Zaproponował udział w krajowym konkursie grantowym (do 5 mln zł, wniosek do końca przyszłego miesiąca)." },
    { "speaker": "Prowadzący", "text": "Zobowiązał dr. Nowaka do przesłania pełnych informacji o konkursie na swój adres e-mail do końca dnia." }
  ]
}
TXT;

function askOllama($systemPrompt, $userPrompt) {
    $payload = [
        "model" => "qwen3:8b",
        "stream" => false,
        "think" => false,
        "format" => "json",
        "messages" => [
            ["role" => "system", "content" => $systemPrompt],
            ["role" => "user", "content" => EXAMPLE_INPUT],
            ["role" => "assistant", "content" => EXAMPLE_OUTPUT],
            ["role" => "user", "content" => $userPrompt]
        ],
        "options" => [
            "temperature" => 0,
            "num_predict" => 2048,
            "num_ctx" => 8192
        ]
    ];
    $ch = curl_init("http://127.0.0.1:11434/api/chat");
    curl_setopt_array($ch, [CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            "Content-Type: application/json"
        ],
        CURLOPT_POSTFIELDS => json_encode(
            $payload,
            JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
        ),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 240
    ]);
    $response = curl_exec($ch);
    $error = curl_error($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($response === false) {
        respond([
            "success" => false,
            "error" => "Nie można połączyć się z Ollama: " . $error
        ], 502);
    }
    if ($status !== 200) {
        respond([
            "success" => false,
            "error" => "Ollama zwróciła HTTP " . $status,
            "details" => $response
        ], 502);
    }
    $ollama = json_decode($response, true);
    $content = $ollama["message"]["content"] ?? "";
    $result = json_decode($content, true);
    if (!is_array($result)) {
        respond([
            "success" => false,
            "error" => "Nieprawidłowa odpowiedź modelu",
            "details" => $content
        ], 502);
    }
    return $result;
}

// Podział stenogramu na punkty obrad
$marker = '(?:Przejdziemy teraz do|Przechodzimy (?:teraz )?do|Przejdźmy (?:teraz )?do)';
$parts = preg_split('/(?=' . $marker . ')/iu', $text);
$parts = array_values(array_filter($parts, fn($p) => trim($p) !== ""));
if (count($parts) > 1 && !preg_match('/^' . $marker . '/iu', $parts[0])) {
    $parts[1] = $parts[0] . "\n" . $parts[1];
    array_shift($parts);
}

$host = "Prowadzący";
if (preg_match('/dyrektor/iu', $text)) {
    $host = "Dyrektor";
} elseif (preg_match('/przewodnicząc/iu', $text)) {
    $host = "Przewodniczący";
} elseif (preg_match('/prezes/iu', $text)) {
    $host = "Prezes";
}

$points = [];
foreach ($parts as $part) {
    $title = "";
    if (preg_match('/' . $marker . '\s+(?:punktu:?\s*)?([^.!?\n]+)/iu', $part, $m)) {
        $title = trim($m[1]);
    }
    $userPrompt = "Prowadzący spotkanie: " . $host
        . "\nTytuł punktu: " . ($title === "" ? "(nieznany)" : $title)
        . "\n\nFragment stenogramu:\n" . $part;
    $result = askOllama($systemPrompt, $userPrompt);

    $entries = [];
    foreach ($result["entries"] ?? [] as $entry) {
        $speaker = trim((string)($entry["speaker"] ?? ""));
        $entryText = trim((string)($entry["text"] ?? ""));
        if ($entryText === "") {
            continue;
        }
        $last = count($entries) - 1;
        if ($last >= 0 && ($speaker === "" || $entries[$last]["speaker"] === $speaker)) {
            $entries[$last]["text"] .= " " . $entryText;
            continue;
        }
        $entries[] = [
            "speaker" => $speaker === "" ? null : $speaker,
            "text" => $entryText
        ];
    }
    $modelTitle = trim((string)($result["title"] ?? ""));
    $points[] = [
        "title" => $modelTitle !== "" ? $modelTitle : ($title !== "" ? $title : "Punkt " . (count($points) + 1)),
        "entries" => $entries
    ];
}

// Wynik dla JavaScript
respond([
    "success" => true,
    "title" => "PROTOKÓŁ I PODSUMOWANIE USTALEŃ ZE SPOTKANIA",
    "points" => $points
]);
