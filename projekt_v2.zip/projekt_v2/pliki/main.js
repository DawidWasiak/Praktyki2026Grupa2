import { english, englishOne, englishTwo } from "./eng.js";
import { polish, polishOne, polishTwo } from "./pol.js";
import { programming } from "./exceptions.js";

let inputext = "";
let FinalResult = [];
let regexFound = null;
let regexReview = [];
let goodregex = "";
let trigramFound = null;
let checkReview = [];
let trigood = "";
let protocol = null;
const statusEl = document.getElementById("status");
const textWindow = document.getElementById("textWindow");
const protocolView = document.getElementById("protocolView");
const regexList = document.getElementById("regexList");
const trigramList = document.getElementById("trigramList");
const dropZone = document.getElementById("dropZone");
const browseButton = document.getElementById("browseButton");
const fileInput = document.getElementById("fileInput");
const next1 = document.getElementById("next1");
const back2 = document.getElementById("back2");
const next2 = document.getElementById("next2");
const back3 = document.getElementById("back3");
const next3 = document.getElementById("next3");
const back4 = document.getElementById("back4");
const plTrigrams = new Set(polish.map(t => t.trigram));
const enTrigrams = new Set(english.map(t => t.trigram));
const shortWords = [...polishOne, ...polishTwo, ...englishOne, ...englishTwo];
const exceptions = [...programming, "mgr", "dr", "prof", "inż", "hab", "zł", "nr", "ul"].map(word => word.toUpperCase());
const fillers = /^(y+|e+|m+|mhm|yhm|no|znaczy|jakby|kurde|kurczę|wiesz|generalnie|uh+|um+|erm|ну|типу|короче)$/iu;
Object.defineProperty(window, "inputext", {
    get: () => inputext
});
Object.defineProperty(window, "FinalResult", {
    get: () => FinalResult
});
Object.defineProperty(window, "regexReview", {
    get: () => regexReview
});
Object.defineProperty(window, "goodregex", {
    get: () => goodregex
});
Object.defineProperty(window, "checkReview", {
    get: () => checkReview
});
Object.defineProperty(window, "trigood", {
    get: () => trigood
});
Object.defineProperty(window, "protocol", {
    get: () => protocol
});
function showStatus(message, isError = false) {
    statusEl.textContent = message;
    statusEl.classList.toggle("error", isError);
}
function showStep(number) {
    for (let i = 1; i <= 4; i++) {
        document.getElementById("krok" + i).hidden = i !== number;
    }
    showStatus("");
}
function cleanSentences(text) {
    return text
        .split(/(?<=[.!?])\s+|\r?\n+/)
        .map(sentence => sentence.trim())
        .filter(sentence => sentence !== "");
}
function bareWord(part) {
    return part.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, "");
}
function regexTest(word, previous) {
    if (fillers.test(word)) return "Wypełniacz";
    if (word.toLowerCase() === previous) return "Powtórzone słowo";
    if (/(\p{L})\1{2,}/u.test(word)) return "Rozciągnięte słowo";
    if (/\p{L}/u.test(word) && /\p{N}/u.test(word)) return "Litery z cyframi";
    if (/\p{Script=Latin}/u.test(word) && /\p{Script=Cyrillic}/u.test(word)) return "Dwa alfabety w jednym słowie";
    if (word.length >= 25) return "Za długie słowo";
    if (word.length >= 4 && /^\p{L}+$/u.test(word) && !/[aeiouyąęóаеєиіїоуюяыэё]/iu.test(word)) return "Brak samogłosek";
    return "";
}
function trigramTest(word) {
    const upper = word.toUpperCase();
    if (exceptions.includes(upper) || /\p{N}/u.test(upper)) return "";
    const keptBefore = regexReview.find(item => item.approved && item.word.toUpperCase() === upper);
    if (keptBefore) return "";
    if (upper.length <= 2) {
        return shortWords.includes(upper) ? "" : "Nieznane krótkie słowo";
    }
    let unknown = 0;
    let total = 0;
    for (let i = 0; i + 3 <= upper.length; i++) {
        const trigram = upper.slice(i, i + 3);
        if (!plTrigrams.has(trigram) && !enTrigrams.has(trigram)) unknown++;
        total++;
    }
    return unknown / total > 0.5 ? "Dziwne połączenia liter (trigramy)" : "";
}
function findSuspicious(text, test, oldList) {
    const parts = text.split(/(\s+)/);
    const list = [];
    const marked = [];
    let previous = "";
    for (let i = 0; i < parts.length; i += 2) {
        const word = bareWord(parts[i]);
        if (word === "") continue;
        const reason = test(word, previous);
        previous = word.toLowerCase();
        if (reason === "") continue;
        marked.push(i);
        let item = list.find(item => item.word.toLowerCase() === word.toLowerCase());
        if (!item) {
            const old = oldList.find(old => old.word.toLowerCase() === word.toLowerCase());
            item = { word: word, count: 0, reason: reason, approved: old ? old.approved : true };
            list.push(item);
        }
        item.count++;
    }
    return { parts, list, marked };
}
function buildText(found) {
    const result = [...found.parts];
    for (const i of found.marked) {
        const word = bareWord(result[i]);
        const item = found.list.find(item => item.word.toLowerCase() === word.toLowerCase());
        if (item && !item.approved) {
            result[i] = result[i].replace(word, "");
        }
    }
    return result
        .join("")
        .replace(/,(\s*,)+/g, ",")
        .replace(/ +([,.!?])/g, "$1")
        .replace(/[ \t]{2,}/g, " ")
        .replace(/^[ \t,]+/gm, "")
        .replace(/(^|[.!?]\s+)(\p{Ll})/gu, (match, before, letter) => before + letter.toUpperCase());
}
function showWords(listEl, list) {
    listEl.innerHTML = "";
    if (list.length === 0) {
        listEl.innerHTML = "<li>Nie znaleziono podejrzanych słów.</li>";
        return;
    }
    list.forEach(item => {
        const li = document.createElement("li");
        const label = document.createElement("label");
        const box = document.createElement("input");
        box.type = "checkbox";
        box.checked = item.approved;
        box.addEventListener("change", () => {
            item.approved = box.checked;
        });
        const word = document.createElement("span");
        word.className = "word";
        word.textContent = item.word + " (" + item.count + ")";
        const reason = document.createElement("span");
        reason.className = "reason";
        reason.textContent = item.reason;
        label.append(box, word, reason);
        li.append(label);
        listEl.append(li);
    });
}
async function sendToPHP(sentences) {
    try {
        showStatus("Trwa tworzenie protokołu, to może potrwać kilka minut...");
        const response = await fetch("przetwarzanie.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                sentences: sentences
            })
        });
        const responseText = await response.text();
        console.log("PHP HTTP status:", response.status);
        console.log("PHP response:", responseText);
        if (!response.ok) {
            throw new Error(
                "HTTP " + response.status + ": " + responseText
            );
        }
        const data = JSON.parse(responseText);
        if (!data.success) {
            throw new Error(
                data.error || "Analiza zakończyła się błędem"
            );
        }
        console.log("Analysis result:", data);
        showStatus("Analiza zakończona pomyślnie");
        return data;
    } catch (error) {
        console.error("PHP error:", error);
        showStatus("Błąd: " + error.message, true);
        return null;
    }
}
function showProtocol(data) {
    protocolView.innerHTML = "";
    const title = document.createElement("h3");
    title.textContent = data.title;
    protocolView.append(title);
    if (data.points.length === 0) {
        const empty = document.createElement("p");
        empty.textContent = "Model nie zwrócił żadnych punktów obrad.";
        protocolView.append(empty);
        return;
    }
    const points = document.createElement("ol");
    data.points.forEach(point => {
        const li = document.createElement("li");
        const pointTitle = document.createElement("strong");
        pointTitle.textContent = point.title;
        li.append(pointTitle);
        const entries = document.createElement("ul");
        point.entries.forEach(entry => {
            const item = document.createElement("li");
            if (entry.speaker) {
                const speaker = document.createElement("strong");
                speaker.textContent = entry.speaker + ": ";
                item.append(speaker);
            }
            item.append(entry.text);
            entries.append(item);
        });
        li.append(entries);
        points.append(li);
    });
    protocolView.append(points);
}
async function importFile(file) {
    if (!file) {
        showStatus("Nie wybrano pliku", true);
        return;
    }
    const name = file.name.toLowerCase();
    if (!name.endsWith(".txt") && file.type !== "text/plain") {
        showStatus("Można wczytać tylko plik TXT", true);
        return;
    }
    try {
        inputext = await file.text();
        if (inputext.trim() === "") {
            showStatus("Plik jest pusty", true);
            return;
        }
        textWindow.value = inputext;
        console.log("Original text:", inputext);
        regexReview = [];
        checkReview = [];
        goodregex = "";
        trigood = "";
        protocol = null;
        showStatus("Plik wczytany: " + file.name);
        next1.disabled = false;
    } catch (error) {
        console.log("Import error:", error);
        showStatus("Nie udało się wczytać pliku", true);
    }
}
function goToRegex() {
    regexFound = findSuspicious(inputext, regexTest, regexReview);
    regexReview = regexFound.list;
    console.log("Regex - do sprawdzenia:", regexReview);
    showWords(regexList, regexReview);
    showStep(2);
}
function goToTrigram() {
    goodregex = buildText(regexFound);
    console.log("goodregex:", goodregex);
    trigramFound = findSuspicious(goodregex, trigramTest, checkReview);
    checkReview = trigramFound.list;
    console.log("Trigramy - do sprawdzenia:", checkReview);
    showWords(trigramList, checkReview);
    showStep(3);
}
async function goToResult() {
    trigood = buildText(trigramFound);
    console.log("trigood:", trigood);
    FinalResult = cleanSentences(trigood);
    console.log(
        "Sentences sent to PHP:",
        JSON.stringify(FinalResult, null, 2)
    );
    back3.disabled = true;
    next3.disabled = true;
    const data = await sendToPHP(FinalResult);
    back3.disabled = false;
    next3.disabled = false;
    if (data) {
        protocol = data;
        console.log("Protokół:", protocol);
        showProtocol(protocol);
        showStep(4);
    }
}
next1.addEventListener("click", goToRegex);
back2.addEventListener("click", () => showStep(1));
next2.addEventListener("click", goToTrigram);
back3.addEventListener("click", () => showStep(2));
next3.addEventListener("click", goToResult);
back4.addEventListener("click", () => showStep(3));
browseButton.addEventListener("click", () => {
    fileInput.click();
});
fileInput.addEventListener("change", () => {
    const file = fileInput.files[0];
    importFile(file);
    fileInput.value = "";
});
dropZone.addEventListener("dragover", event => {
    event.preventDefault();
    dropZone.classList.add("dragover");
});
dropZone.addEventListener("dragleave", () => {
    dropZone.classList.remove("dragover");
});
dropZone.addEventListener("drop", event => {
    event.preventDefault();
    dropZone.classList.remove("dragover");
    const file = event.dataTransfer.files[0];
    importFile(file);
});
window.addEventListener("dragover", event => {
    event.preventDefault();
});
window.addEventListener("drop", event => {
    event.preventDefault();
});
