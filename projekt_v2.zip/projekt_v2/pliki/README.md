# Protokół ze spotkania

Program zamienia surowy stenogram spotkania (plik `.txt` z rozpoznawania mowy) na uporządkowany protokół. Czyści tekst, daje człowiekowi do sprawdzenia podejrzane słowa i wysyła wynik do lokalnego modelu LLM (Ollama).

## Wymagania

- **XAMPP** (Apache + PHP 8). Strony nie można otwierać jako pliku (`file://`), bo przeglądarka zablokuje `main.js`.
- **Ollama** z pobranym modelem, np. `ollama pull qwen3:8b`.

## Uruchomienie

1. Skopiuj folder `pliki` do `C:\xampp\htdocs\` (np. jako `protokol`).
2. Uruchom Apache w XAMPP i Ollamę.
3. Otwórz `http://localhost/protokol/index.html`.

## Jak działa program

```
plik .txt
  → Krok 2: regex      (człowiek odznacza słowa do usunięcia)
  → Krok 3: trigramy   (człowiek odznacza słowa do usunięcia)
  → PHP dzieli tekst na punkty obrad
  → dla każdego punktu:
       LLM krok 1: tematy, decyzje, zadania, otwarte pytania (JSON)
       LLM krok 2: wpisy protokołu na podstawie kroku 1 (JSON)
  → Krok 4: gotowy protokół + podsumowanie, plik JSON
```

1. **Wczytaj tekst.** Przeciągnij plik `.txt` albo kliknij BROWSE.
2. **Regex.** Program pokazuje wypełniacze (`yyy`, `kurde`), powtórzenia, rozciągnięte słowa itd. Zaznaczone słowa zostają w tekście, odznaczone są usuwane.
3. **Trigramy.** Każde słowo jest dzielone na trzyliterowe kawałki (`NIE`, `DZI`...) i porównywane z tabelami częstości dla polskiego i angielskiego. Słowa z dziwnymi połączeniami liter trafiają na listę. Odznacz te, które trzeba usunąć.
4. **Protokół.** Po kliknięciu „Dalej” tekst idzie do PHP, a PHP pyta LLM dwa razy dla każdego punktu obrad. Wynik widać na stronie. Przycisk „Pobierz JSON” go pobiera, a kopia zapisuje się sama w folderze `wyniki/`.

## Pliki

| Plik | Za co odpowiada |
|---|---|
| `index.html` | wygląd strony, 4 kroki |
| `style.css` | style |
| `main.js` | logika w przeglądarce: wczytanie pliku, regex, trigramy, wysłanie do PHP, wyświetlenie wyniku |
| `pol.js`, `eng.js` | tabele trigramów z częstościami i listy krótkich słów |
| `exceptions.js` | słowa, które trigramy zawsze akceptują (np. nazwy języków programowania) |
| `przetwarzanie.php` | podział na punkty obrad, dwa zapytania do Ollama, zapis JSON |
| `ustawienia.txt` | **wszystkie ustawienia** (patrz niżej) |
| `wyniki/` | zapisane protokoły `.json` (tworzy się sam) |

## Ustawienia (`ustawienia.txt`)

Format: `klucz: wartość`. Lista to linie zaczynające się od `- `. Linie z `#` są komentarzami. `tak` / `nie` włącza lub wyłącza opcję. Po zmianie zapisz plik i odśwież stronę (F5).

### `[cleaning]` — krok 2 (regex)
| Klucz | Znaczenie |
|---|---|
| `wypelniacze_wlacz`, `wypelniacze_regex` | wykrywanie wypełniaczy. Nowe słowo dopisz w nawiasie po `\|` |
| `powtorzone_slowo` | to samo słowo dwa razy pod rząd |
| `rozciagniete_slowo`, `rozciagniete_min_powtorzen` | „dooobrze”: ile razy ta sama litera pod rząd |
| `litery_z_cyframi` | litery i cyfry w jednym słowie |
| `dwa_alfabety` | łacinka i cyrylica w jednym słowie |
| `za_dlugie_slowo`, `za_dlugie_min_dlugosc` | słowa dłuższe niż limit |
| `brak_samoglosek`, `..._min_dlugosc`, `samogloski` | słowa bez samogłosek |
| `wlasne_regex` | własne reguły: `- regex => powód` |

### `[n-gram_values]` — krok 3 (trigramy)
| Klucz | Znaczenie |
|---|---|
| `trigramy_wlacz` | włącza lub wyłącza cały krok |
| `waga_polski`, `waga_angielski` | ile „znaczy” trigram znaleziony w danym języku (0–1) |
| `min_czestosc` | trigram jest znany tylko, gdy jego częstość (%) jest ≥ tej wartości |
| `prog` | słowo jest podejrzane, gdy udział nieznanych trigramów > `prog` |
| `sprawdzaj_krotkie_slowa`, `krotkie_slowo_max_dlugosc` | słowa 1–2 literowe sprawdzane ze słownikiem |
| `wyjatki` | słowa zawsze OK, po przecinku |

### `[llm_settings]` — model i wynik
| Klucz | Znaczenie |
|---|---|
| `model` | nazwa modelu w Ollama (np. `qwen3:8b`) |
| `url` | adres API Ollama |
| `think`, `temperature`, `num_predict`, `num_ctx` | parametry modelu |
| `timeout_sekundy` | maks. czas na jedną odpowiedź |
| `repeat_penalty` | kara za powtórzenia, pomaga gdy mały model się zapętla |
| `ponowienia` | ile razy ponowić zapytanie przy zepsutym JSON (każda próba: temperatura +0.3, repeat_penalty +0.1) |
| `limit_calkowity_sekundy` | maks. czas całego przetwarzania (wszystkie punkty) |
| `przyklad` | czy pokazywać modelowi przykład dobrej odpowiedzi |
| `nowy_punkt` | zdania, od których zaczyna się nowy punkt obrad (regex) |
| `tytul_z_modelu` | `nie` = tytuł punktu dokładnie ze stenogramu, `tak` = poprawiony przez model |
| `prowadzacy_domyslnie`, `prowadzacy` | nazwa prowadzącego: `- słowo w tekście => nazwa` |
| `tytul_protokolu`, `zapisz_json`, `folder_wynikow` | tytuł i zapis pliku |

### `[llm_krok1_analiza]` i `[llm_krok2_protokol]` — jak LLM przetwarza tekst
- `rola` mówi modelowi, kim jest.
- `zasady` to lista poleceń, jedno w linii po `- `. Numerowane są automatycznie, więc można je dowolnie dodawać i usuwać.

### `[poprawki_po_llm]` — zamiany po odpowiedzi modelu
- `zamiany`: lista `- regex => zamiana`. PHP stosuje je do każdego wpisu protokołu. Pusta zamiana usuwa dopasowany tekst.
- Przydaje się, gdy model mimo zasad powtarza ten sam błąd (np. „Zamykał” zamiast „Zamknął”).

Format odpowiedzi (JSON) jest ustawiony w PHP i nie da się go zmienić z pliku, bo PHP musi umieć go odczytać.

## Częste problemy

- **„Nie można połączyć się z Ollama”**: Ollama nie działa albo `url` jest zły.
- **„Ollama zwróciła HTTP 404”**: model z `model:` nie jest pobrany (`ollama list`).
- **Błędny regex**: program go pomija i pisze ostrzeżenie w konsoli (F12).
- **Trwa bardzo długo**: dla każdego punktu obrad idą 2 zapytania. Można zmniejszyć `num_ctx` albo użyć mniejszego modelu.

## Znane ograniczenia

- Mały model (np. `qwen3:8b`) czasem gubi szczegół (np. procent), robi literówkę albo pisze niezgrabne zdanie. Wynik zawsze warto przeczytać przed użyciem.
- Powtarzające się błędy modelu można poprawić w `[poprawki_po_llm]`. Przy większych problemach pomoże większy model (`model:`).
- Trigramy czasem oznaczają prawdziwe, ale rzadkie polskie słowa. Wtedy zostaw je zaznaczone albo dopisz do `wyjatki`.
