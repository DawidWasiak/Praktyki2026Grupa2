let inputext = "";
let FinalResult = [];
const dropZone = document.getElementById("dropZone");
const browseButton = document.getElementById("browseButton");
const fileInput = document.getElementById("fileInput");
const textWindow = document.getElementById("textWindow");
const statusEl = document.getElementById("status");
Object.defineProperty(window, "inputext", {
    get: () => inputext
});
Object.defineProperty(window, "FinalResult", {
    get: () => FinalResult
});
function showStatus(message, isError = false) {
    statusEl.textContent = message;
    statusEl.classList.toggle("error", isError);
}
function cleanSentences(text) {
    return text
        .split(/(?<=[.!?])\s+|\r?\n+/)
        .map(sentence => sentence.trim())
        .filter(sentence => sentence !== "");
}
async function importFile(file) {
    if (!file) {
        showStatus("Nie wybrano pliku", true);
        return;
    }
    const name = file.name.toLowerCase();
    if (!name.endsWith(".txt") && file.type !== "text/plain") {
        showStatus("Można wczytać tylko plik TXT", true);
        return;
    }
    try {
        inputext = await file.text();
        if (inputext.trim() === "") {
            showStatus("Plik jest pusty", true);
            return;
        }
        textWindow.value = inputext;
        FinalResult = cleanSentences(inputext);
        console.log("Original text:", inputext);
        console.log(
            "Sentences sent to PHP:",
            JSON.stringify(FinalResult, null, 2)
        );
        showStatus("Plik wczytany: " + file.name);
        await sendToPHP(FinalResult);
    } catch (error) {
        console.log("Import error:", error);
        showStatus("Nie udało się wczytać pliku", true);
    }
}
async function sendToPHP(sentences) {
    try {
        showStatus("Trwa analiza tekstu...");
        const response = await fetch("przetwarzanie.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                sentences: sentences
            })
        });
        const responseText = await response.text();
        console.log("PHP HTTP status:", response.status);
        console.log("PHP response:", responseText);
        if (!response.ok) {
            throw new Error(
                "HTTP " + response.status + ": " + responseText
            );
        }
        const data = JSON.parse(responseText);
        if (!data.success) {
            throw new Error(
                data.error || "Analiza zakończyła się błędem"
            );
        }
        console.log("Analysis result:", data);
        console.log(
            JSON.stringify(data.tasks, null, 2)
        );
        showStatus("Analiza zakończona pomyślnie");
    } catch (error) {
        console.error("PHP error:", error);
        showStatus("Błąd: " + error.message, true);
    }
}
browseButton.addEventListener("click", () => {
    fileInput.click();
});
fileInput.addEventListener("change", () => {
    const file = fileInput.files[0];
    importFile(file);
    fileInput.value = "";
});
dropZone.addEventListener("dragover", event => {
    event.preventDefault();
    dropZone.classList.add("dragover");
});
dropZone.addEventListener("dragleave", () => {
    dropZone.classList.remove("dragover");
});
dropZone.addEventListener("drop", event => {
    event.preventDefault();
    dropZone.classList.remove("dragover");
    const file = event.dataTransfer.files[0];
    importFile(file);
});
window.addEventListener("dragover", event => {
    event.preventDefault();
});
window.addEventListener("drop", event => {
    event.preventDefault();
});