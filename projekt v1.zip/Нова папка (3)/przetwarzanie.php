<?php
set_time_limit(300);
header("Content-Type: application/json; charset=utf-8");
function respond($data, $status = 200) {
    http_response_code($status);
    echo json_encode(
        $data,
        JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
    );
    exit;
}
// Odczyt danych z JavaScript
$input = file_get_contents("php://input");
$data = json_decode($input, true);
if (
    !is_array($data) ||
    !isset($data["sentences"]) ||
    !is_array($data["sentences"])
) {
    respond([
        "success" => false,
        "error" => "Nieprawidłowe dane wejściowe"
    ], 400);
}

// 2. Zachowujemy oryginalne zdania
$sentences = array_values(array_filter(
    $data["sentences"],
    fn($s) => is_string($s) && trim($s) !== ""
));
$text = implode("\n", $sentences);

if (trim($text) === "") {
    respond([
        "success" => false,
        "error" => "Brak tekstu do analizy"
    ], 400);
}
// Instrukcje dla modelu
$systemPrompt = <<<'PROMPT'
Jesteś asystentem analizującym transkrypcje spotkań.

Transkrypcja pochodzi z automatycznego rozpoznawania mowy (ASR).
Może zawierać błędnie rozpoznane słowa, zniekształcone nazwy,
nieznane terminy oraz fragmenty bez sensu.

Twoim zadaniem jest wyodrębnić konkretne zadania wynikające
z treści spotkania i zwrócić je w poprawnym formacie JSON.

Zasady analizy:

1. Zachowuj ważne informacje z transkrypcji.
2. Interpretuj błędnie rozpoznane słowa na podstawie kontekstu,
   ale poprawiaj ich znaczenie tylko wtedy, gdy jest to uzasadnione.
3. Nie wymyślaj osób, nazwisk, terminów, kwot ani ustaleń.
4. Odróżniaj propozycje od decyzji i uzgodnionych zadań.
5. Nie zamieniaj każdej omawianej kwestii w zadanie.
6. Sama informacja, że coś nie zostało zatwierdzone,
   nie oznacza zadania do zatwierdzenia.
7. Jeśli wyraźnie przydzielono zadanie konkretnej osobie,
   wpisz tę osobę w polu "who".
8. Jeśli zadanie przyjęto wspólnie, ale nie wskazano osoby,
   użyj "Zespół" tylko wtedy, gdy tekst rzeczywiście wskazuje
   na wspólną odpowiedzialność. W przeciwnym razie użyj null.
9. Zachowuj warunki wykonania zadania, np. "po otrzymaniu ofert".
10. Jeśli termin nie został określony, użyj null.
11. Jeśli tekst mówi o braku ustalonego terminu, nie wymyślaj go.
12. Nie pomijaj konkretnych zadań tylko dlatego, że obok nich
    występują niezrozumiałe fragmenty.
13. Nie twórz zadań na podstawie samej propozycji, jeśli nie
    ustalono, że ma być realizowana.
14. Nie traktuj informacji o kolejnym spotkaniu jako zadania,
    chyba że transkrypcja wskazuje konkretną czynność do wykonania.
15. Jeżeli nie ma żadnych konkretnych zadań, zwróć pustą tablicę.

16. Nie traktuj propozycji jako uzgodnionego zadania. Jeśli ktoś jedynie proponuje zaproszenie gości, nie twórz zadania, dopóki uczestnicy nie zaakceptują propozycji lub nie ustalą jej realizacji.

17. Jeśli tekst mówi, że zespół zgodził się wykonać zadanie, ale nie wskazano konkretnej osoby, ustaw "who" na "Zespół".

18. Nie twórz zadania wyłącznie na podstawie informacji o aktualnym stanie, np. że budżet nie został zatwierdzony. Zadanie musi wynikać z wyraźnego ustalenia, polecenia lub przydzielenia odpowiedzialności.

19. Informacja o planowanym spotkaniu nie jest zadaniem. Nie dodawaj spotkań do tablicy "tasks".

20. Rozróżniaj opis obowiązku od informacji o braku ustaleń. Zdanie, że nie wiadomo jeszcze, kto przygotuje formularz, nie oznacza, że konkretnej osobie przydzielono to zadanie.

21. Jeśli zadanie ma warunek realizacji, zachowaj go w polu "how", np. "po otrzymaniu ofert".

22. Nie pomijaj wykonawcy wskazanego bezpośrednio w zdaniu. Jeśli tekst mówi "Tomasz Wójcik sprawdzi...", ustaw "who" na "Tomasz Wójcik".

23. Nie dodawaj zadań, których wykonania nie uzgodniono. W razie wątpliwości nie przedstawiaj samego tematu rozmowy jako zadania.

24. Jeśli w zdaniu konkretna osoba jest podmiotem czynności, przypisz jej imię i nazwisko do pola "who". Dotyczy to również zdań, w których osoba jest wskazana bezpośrednio przed czasownikiem, np. "Tomasz Wójcik sprawdzi dostępność sali". Nie ustawiaj "who" na null, jeśli wykonawca jest jasno określony w tekście.

25. Formułuj pole "action" jako konkretną czynność w bezokoliczniku, np. "sprawdzić dostępność sali", "przygotować listę gości", "wybrać sposób transmisji". Unikaj rzeczowników odczasownikowych, jeśli można użyć bezokolicznika.

26. Nie twórz zadania dotyczącego przygotowania formularza, strony internetowej ani innego narzędzia wyłącznie na podstawie informacji, że będzie ono wykorzystywane w procesie. Jeśli tekst mówi, że nie ustalono, kto ma przygotować formularz, nie dodawaj tego jako zadania, chyba że wyraźnie uzgodniono samo jego przygotowanie jako osobną czynność do wykonania.

PRZYKŁADY PRAWIDŁOWEJ KLASYFIKACJI:

- "Ewa zaproponowała zaproszenie dwóch prelegentów."
  -> NIE dodawaj zadania. To tylko propozycja.

- "Zespół zgodził się przygotować listę gości."
  -> Dodaj zadanie z "who": "Zespół".

- "Tomasz sprawdzi dostępność sali i poinformuje o kosztach."
  -> Dodaj zadanie z "who": "Tomasz".

- "Nie ustalono, kto przygotuje formularz."
  -> NIE dodawaj zadania dotyczącego formularza.

- "Budżet nie został zatwierdzony."
  -> NIE dodawaj zadania dotyczącego zatwierdzenia budżetu.

- "Decyzja zostanie podjęta po otrzymaniu ofert."
  -> Dodaj zadanie wyboru rozwiązania, z warunkiem w polu "how".

- "Następne spotkanie odbędzie się w przyszłym tygodniu."
  -> NIE dodawaj spotkania do "tasks".

Przykłady mają pierwszeństwo przy klasyfikowaniu podobnych sytuacji.
Nie twórz zadania, jeśli tekst opisuje tylko propozycję,
niepewność, stan bieżący lub planowane wydarzenie.
{
  "tasks": [
    {
      "who": null,
      "action": "opis konkretnego zadania",
      "when": null,
      "where": null,
      "how": null
    }
  ]
}

Znaczenie pól:
- who: osoba lub zespół odpowiedzialny; null, jeśli nie wiadomo.
- action: konkretna czynność wynikająca z transkrypcji.
- when: termin wykonania; null, jeśli nie został podany.
- where: miejsce wykonania; null, jeśli nie zostało podane.
- how: sposób wykonania lub warunek; null, jeśli nie został podany.

Wartości nieznane zapisuj jako prawdziwy JSON null.
Nie dodawaj komentarzy ani tekstu poza JSON-em.
PROMPT;
$userPrompt = "Przeanalizuj poniższą transkrypcję:\n\n" . $text;

// Żądanie do Ollama
$payload = [
    "model" => "qwen3:8b",
    "stream" => false,
    "think" => false,
    "format" => "json",
    "messages" => [
        [
            "role" => "system",
            "content" => $systemPrompt
        ],
        [
            "role" => "user",
            "content" => $userPrompt
        ]
    ],
    "options" => [
        "temperature" => 0,
        "num_predict" => 1024
    ]
];
$ch = curl_init("http://127.0.0.1:11434/api/chat");
curl_setopt_array($ch, [CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/json"
    ],
    CURLOPT_POSTFIELDS => json_encode(
        $payload,
        JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
    ),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 5,
    CURLOPT_TIMEOUT => 180
]);
$response = curl_exec($ch);
$error = curl_error($ch);
$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
if ($response === false) {
    respond([
        "success" => false,
        "error" => "Nie można połączyć się z Ollama: " . $error
    ], 502);
}
if ($status !== 200) {
    respond([
        "success" => false,
        "error" => "Ollama zwróciła HTTP " . $status,
        "details" => $response
    ], 502);
}
// Odczyt odpowiedzi modelu
$ollama = json_decode($response, true);
$content = $ollama["message"]["content"] ?? "";
$result = json_decode($content, true);
if (
    !is_array($result) ||
    !isset($result["tasks"]) ||
    !is_array($result["tasks"])
) {
    respond([
        "success" => false,
        "error" => "Nieprawidłowa odpowiedź modelu",
        "details" => $content
    ], 502);
}
$validatedTasks = [];
foreach ($result["tasks"] as $task) {
    if (!is_array($task)) {
        continue;
    }
    $action = $task["action"] ?? null;

    if (!is_string($action) || trim($action) === "") {
        continue;
    }
    $cleanTask = [
        "who" => $task["who"] ?? null,
        "action" => trim($action),
        "when" => $task["when"] ?? null,
        "where" => $task["where"] ?? null,
        "how" => $task["how"] ?? null
    ];
    foreach (["who", "when", "where", "how"] as $key) {
        if (
            !is_string($cleanTask[$key]) ||
            trim($cleanTask[$key]) === "" ||
            strtolower(trim($cleanTask[$key])) === "null"
        ) {
            $cleanTask[$key] = null;
        } else {
            $cleanTask[$key] = trim($cleanTask[$key]);
        }
    }
    $validatedTasks[] = $cleanTask;
}
// Wynik dla JavaScript
respond([
    "success" => true,
    "tasks" => $validatedTasks
]);