import { english, englishOne, englishTwo } from "./eng.js";
import { polish, polishOne, polishTwo } from "./pol.js";
import { programming } from "./exceptions.js";

let inputext = "";
let FinalResult = [];
let regexFound = null;
let regexReview = [];
let goodregex = "";
let trigramFound = null;
let checkReview = [];
let trigood = "";
let protocol = null;
const statusEl = document.getElementById("status");
const textWindow = document.getElementById("textWindow");
const protocolView = document.getElementById("protocolView");
const regexList = document.getElementById("regexList");
const trigramList = document.getElementById("trigramList");
const dropZone = document.getElementById("dropZone");
const browseButton = document.getElementById("browseButton");
const fileInput = document.getElementById("fileInput");
const next1 = document.getElementById("next1");
const back2 = document.getElementById("back2");
const next2 = document.getElementById("next2");
const back3 = document.getElementById("back3");
const next3 = document.getElementById("next3");
const back4 = document.getElementById("back4");
const downloadButton = document.getElementById("downloadJson");
const summaryView = document.getElementById("summaryView");
const plTrigrams = new Map(polish.map(t => [t.trigram, t.freq]));
const enTrigrams = new Map(english.map(t => [t.trigram, t.freq]));
const shortWords = [...polishOne, ...polishTwo, ...englishOne, ...englishTwo];

// Ustawienia z pliku ustawienia.txt
function parseSettings(text) {
    const out = {};
    let section = null;
    let listKey = null;
    for (const raw of text.split(/\r?\n/)) {
        const line = raw.trim();
        if (line === "" || line.startsWith("#")) continue;
        const header = line.match(/^\[(.+)\]$/);
        if (header) {
            section = out[header[1].trim().toLowerCase()] = {};
            listKey = null;
            continue;
        }
        if (!section) continue;
        if (line.startsWith("- ")) {
            if (listKey) {
                if (!Array.isArray(section[listKey])) section[listKey] = [];
                section[listKey].push(line.slice(2).trim());
            }
            continue;
        }
        const colon = line.indexOf(":");
        if (colon < 0) continue;
        listKey = line.slice(0, colon).trim().toLowerCase();
        section[listKey] = line.slice(colon + 1).trim();
    }
    return out;
}
const yes = (value, def = true) => value === undefined || value === "" ? def : /^(tak|true|1|yes|on)$/i.test(value);
const num = (value, def) => {
    const n = parseFloat(String(value ?? "").replace(",", "."));
    return Number.isFinite(n) ? n : def;
};
const asList = value => Array.isArray(value) ? value : [];
let settings = {};
let settingsWarning = "";
try {
    const response = await fetch("ustawienia.txt", { cache: "no-store" });
    if (!response.ok) throw new Error("HTTP " + response.status);
    settings = parseSettings(await response.text());
} catch (error) {
    console.error("ustawienia.txt error:", error);
    settingsWarning = "Nie można wczytać ustawienia.txt - działają ustawienia domyślne";
    statusEl.textContent = settingsWarning;
    statusEl.classList.add("error");
}
const C = settings["cleaning"] || {};
const N = settings["n-gram_values"] || {};
function safeRegex(pattern, flags, what) {
    try {
        return new RegExp(pattern, flags);
    } catch (error) {
        console.warn("Błędny regex w ustawieniach (" + what + "):", pattern, error);
        return null;
    }
}
const R = {
    fillers: yes(C.wypelniacze_wlacz),
    repeated: yes(C.powtorzone_slowo),
    stretchedOn: yes(C.rozciagniete_slowo),
    digits: yes(C.litery_z_cyframi),
    alphabets: yes(C.dwa_alfabety),
    tooLong: yes(C.za_dlugie_slowo),
    tooLongMin: num(C.za_dlugie_min_dlugosc, 25),
    noVowels: yes(C.brak_samoglosek),
    noVowelsMin: num(C.brak_samoglosek_min_dlugosc, 4)
};
const T = {
    on: yes(N.trigramy_wlacz),
    polish_weight: num(N.waga_polski, 1),
    english_weight: num(N.waga_angielski, 1),
    min_freq: num(N.min_czestosc, 0),
    threshold: num(N.prog, 0.5),
    check_short_words: yes(N.sprawdzaj_krotkie_slowa),
    short_word_max_length: num(N.krotkie_slowo_max_dlugosc, 2),
    exceptions: (N.wyjatki ?? "mgr, dr, prof, inż, hab, zł, nr, ul").split(",").map(w => w.trim()).filter(Boolean)
};
const exceptions = [...programming, ...T.exceptions].map(word => word.toUpperCase());
const fillers = R.fillers
    ? safeRegex(C.wypelniacze_regex || "^(y+|e+|m+|mhm|yhm)$", "iu", "wypelniacze_regex")
    : null;
const customRules = asList(C.wlasne_regex).map(item => {
    const [pattern, reason] = item.split("=>").map(part => part.trim());
    const regex = safeRegex(pattern, "iu", "wlasne_regex");
    return regex ? { regex, reason: reason || "Własna reguła" } : null;
}).filter(Boolean);
const stretched = new RegExp("(\\p{L})\\1{" + Math.max(1, num(C.rozciagniete_min_powtorzen, 3) - 1) + ",}", "u");
const vowels = new RegExp("[" + (C.samogloski || "aeiouyąęó") + "]", "iu");
Object.defineProperty(window, "inputext", {
    get: () => inputext
});
Object.defineProperty(window, "FinalResult", {
    get: () => FinalResult
});
Object.defineProperty(window, "regexReview", {
    get: () => regexReview
});
Object.defineProperty(window, "goodregex", {
    get: () => goodregex
});
Object.defineProperty(window, "checkReview", {
    get: () => checkReview
});
Object.defineProperty(window, "trigood", {
    get: () => trigood
});
Object.defineProperty(window, "protocol", {
    get: () => protocol
});
function showStatus(message, isError = false) {
    statusEl.textContent = message;
    statusEl.classList.toggle("error", isError);
}
function showStep(number) {
    for (let i = 1; i <= 4; i++) {
        document.getElementById("krok" + i).hidden = i !== number;
    }
    showStatus("");
}
function cleanSentences(text) {
    // Pojedyncze przejścia do nowej linii (zawijanie tekstu) traktujemy jak spację
    return text
        .replace(/[ \t]*\r?\n[ \t]*/g, " ")
        .split(/(?<=[.!?])\s+/)
        .map(sentence => sentence.trim())
        .filter(sentence => sentence !== "");
}
function bareWord(part) {
    return part.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, "");
}
function regexTest(word, previous) {
    if (fillers && fillers.test(word)) return "Wypełniacz";
    if (R.repeated && word.toLowerCase() === previous) return "Powtórzone słowo";
    if (R.stretchedOn && stretched.test(word)) return "Rozciągnięte słowo";
    if (R.digits && /\p{L}/u.test(word) && /\p{N}/u.test(word)) return "Litery z cyframi";
    if (R.alphabets && /\p{Script=Latin}/u.test(word) && /\p{Script=Cyrillic}/u.test(word)) return "Dwa alfabety w jednym słowie";
    if (R.tooLong && word.length >= R.tooLongMin) return "Za długie słowo";
    if (R.noVowels && word.length >= R.noVowelsMin && /^\p{L}+$/u.test(word) && !vowels.test(word)) return "Brak samogłosek";
    for (const rule of customRules) {
        if (rule.regex.test(word)) return rule.reason;
    }
    return "";
}
function trigramKnown(map, trigram) {
    return map.has(trigram) && map.get(trigram) >= (T.min_freq ?? 0) ? 1 : 0;
}
function trigramTest(word) {
    if (T.on === false) return "";
    const upper = word.toUpperCase();
    if (exceptions.includes(upper) || /\p{N}/u.test(upper)) return "";
    const keptBefore = regexReview.find(item => item.approved && item.word.toUpperCase() === upper);
    if (keptBefore) return "";
    if (upper.length <= (T.short_word_max_length ?? 2)) {
        if (T.check_short_words === false) return "";
        return shortWords.includes(upper) ? "" : "Nieznane krótkie słowo";
    }
    if (upper.length < 3) return "";
    const plWeight = T.polish_weight ?? 1;
    const enWeight = T.english_weight ?? 1;
    let unknown = 0;
    let total = 0;
    for (let i = 0; i + 3 <= upper.length; i++) {
        const trigram = upper.slice(i, i + 3);
        const known = plWeight * trigramKnown(plTrigrams, trigram) + enWeight * trigramKnown(enTrigrams, trigram);
        unknown += 1 - Math.min(1, known);
        total++;
    }
    return unknown / total > (T.threshold ?? 0.5) ? "Dziwne połączenia liter (trigramy)" : "";
}
function findSuspicious(text, test, oldList) {
    const parts = text.split(/(\s+)/);
    const list = [];
    const marked = [];
    let previous = "";
    for (let i = 0; i < parts.length; i += 2) {
        const word = bareWord(parts[i]);
        if (word === "") continue;
        const reason = test(word, previous);
        previous = word.toLowerCase();
        if (reason === "") continue;
        marked.push(i);
        let item = list.find(item => item.word.toLowerCase() === word.toLowerCase());
        if (!item) {
            const old = oldList.find(old => old.word.toLowerCase() === word.toLowerCase());
            item = { word: word, count: 0, reason: reason, approved: old ? old.approved : true };
            list.push(item);
        }
        item.count++;
    }
    return { parts, list, marked };
}
function buildText(found) {
    const result = [...found.parts];
    for (const i of found.marked) {
        const word = bareWord(result[i]);
        const item = found.list.find(item => item.word.toLowerCase() === word.toLowerCase());
        if (item && !item.approved) {
            result[i] = result[i].replace(word, "");
        }
    }
    return result
        .join("")
        .replace(/,(\s*,)+/g, ",")
        .replace(/ +([,.!?])/g, "$1")
        .replace(/[ \t]{2,}/g, " ")
        .replace(/^[ \t,]+/gm, "")
        .replace(/(^|[.!?]\s+)(\p{Ll})/gu, (match, before, letter) => before + letter.toUpperCase());
}
function showWords(listEl, list) {
    listEl.innerHTML = "";
    if (list.length === 0) {
        listEl.innerHTML = "<li>Nie znaleziono podejrzanych słów.</li>";
        return;
    }
    list.forEach(item => {
        const li = document.createElement("li");
        const label = document.createElement("label");
        const box = document.createElement("input");
        box.type = "checkbox";
        box.checked = item.approved;
        box.addEventListener("change", () => {
            item.approved = box.checked;
        });
        const word = document.createElement("span");
        word.className = "word";
        word.textContent = item.word + " (" + item.count + ")";
        const reason = document.createElement("span");
        reason.className = "reason";
        reason.textContent = item.reason;
        label.append(box, word, reason);
        li.append(label);
        listEl.append(li);
    });
}
async function sendToPHP(sentences) {
    try {
        showStatus("LLM: krok 1 (analiza) + krok 2 (protokół) dla każdego punktu. To może potrwać kilka minut...");
        const response = await fetch("przetwarzanie.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                sentences: sentences
            })
        });
        const responseText = await response.text();
        console.log("PHP HTTP status:", response.status);
        console.log("PHP response:", responseText);
        if (!response.ok) {
            throw new Error(
                "HTTP " + response.status + ": " + responseText
            );
        }
        const data = JSON.parse(responseText);
        if (!data.success) {
            throw new Error(
                data.error || "Analiza zakończyła się błędem"
            );
        }
        console.log("Analysis result:", data);
        showStatus("Gotowe" + (data.saved_file ? ". Zapisano plik: " + data.saved_file : ""));
        return data;
    } catch (error) {
        console.error("PHP error:", error);
        showStatus("Błąd: " + error.message, true);
        return null;
    }
}
function showProtocol(data) {
    protocolView.innerHTML = "";
    const title = document.createElement("h3");
    title.textContent = data.title;
    protocolView.append(title);
    if (data.points.length === 0) {
        const empty = document.createElement("p");
        empty.textContent = "Model nie zwrócił żadnych punktów obrad.";
        protocolView.append(empty);
        return;
    }
    const points = document.createElement("ol");
    data.points.forEach(point => {
        const li = document.createElement("li");
        const pointTitle = document.createElement("strong");
        pointTitle.textContent = point.title;
        li.append(pointTitle);
        const entries = document.createElement("ul");
        point.entries.forEach(entry => {
            const item = document.createElement("li");
            if (entry.speaker) {
                const speaker = document.createElement("strong");
                speaker.textContent = entry.speaker + ": ";
                item.append(speaker);
            }
            item.append(entry.text);
            entries.append(item);
        });
        li.append(entries);
        points.append(li);
    });
    protocolView.append(points);
}
function addList(parent, heading, items, makeText) {
    const h = document.createElement("h4");
    h.textContent = heading;
    parent.append(h);
    if (items.length === 0) {
        const p = document.createElement("p");
        p.className = "hint";
        p.textContent = "Brak";
        parent.append(p);
        return;
    }
    const ul = document.createElement("ul");
    items.forEach(item => {
        const li = document.createElement("li");
        li.textContent = makeText(item);
        ul.append(li);
    });
    parent.append(ul);
}
// Tematy pogrupowane według punktów obrad, w tej samej kolejności co protokół
function showTopics(parent, topics) {
    const h = document.createElement("h4");
    h.textContent = "Tematy";
    parent.append(h);
    if (topics.length === 0) {
        const p = document.createElement("p");
        p.className = "hint";
        p.textContent = "Brak";
        parent.append(p);
        return;
    }
    const groups = new Map();
    topics.forEach(t => {
        const key = typeof t === "string" ? "" : (t.nr ? t.nr + ". " : "") + t.point;
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key).push(typeof t === "string" ? t : t.text);
    });
    const ol = document.createElement("ul");
    groups.forEach((list, key) => {
        const li = document.createElement("li");
        const strong = document.createElement("strong");
        strong.textContent = key;
        const inner = document.createElement("ul");
        list.forEach(text => {
            const sub = document.createElement("li");
            sub.textContent = text;
            inner.append(sub);
        });
        li.append(strong, inner);
        ol.append(li);
    });
    parent.append(ol);
}
function showSummary(data) {
    summaryView.innerHTML = "";
    const s = data.summary || {};
    const title = document.createElement("h3");
    title.textContent = "Podsumowanie (krok 1 LLM)";
    summaryView.append(title);
    const where = item => " [" + (item.nr ? item.nr + ". " : "") + item.point + "]";
    showTopics(summaryView, s.topics || []);
    addList(summaryView, "Decyzje", s.decisions || [], d => d.text + where(d));
    addList(summaryView, "Zadania", s.action_items || [], a =>
        (a.who ? a.who + ": " : "") + a.task + (a.type === "deklaracja" ? " (deklaracja)" : "") + (a.deadline ? " (termin: " + a.deadline + ")" : "") + where(a));
    addList(summaryView, "Otwarte pytania", s.open_questions || [], q => q.text + where(q));
}
function downloadProtocol() {
    if (!protocol) return;
    const blob = new Blob([JSON.stringify(protocol, null, 2)], { type: "application/json" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "protokol.json";
    link.click();
    URL.revokeObjectURL(link.href);
}
async function importFile(file) {
    if (!file) {
        showStatus("Nie wybrano pliku", true);
        return;
    }
    const name = file.name.toLowerCase();
    if (!name.endsWith(".txt") && file.type !== "text/plain") {
        showStatus("Można wczytać tylko plik TXT", true);
        return;
    }
    try {
        inputext = await file.text();
        if (inputext.trim() === "") {
            showStatus("Plik jest pusty", true);
            return;
        }
        textWindow.value = inputext;
        console.log("Original text:", inputext);
        regexReview = [];
        checkReview = [];
        goodregex = "";
        trigood = "";
        protocol = null;
        showStatus("Plik wczytany: " + file.name + (settingsWarning ? ". UWAGA: " + settingsWarning : ""), settingsWarning !== "");
        next1.disabled = false;
    } catch (error) {
        console.log("Import error:", error);
        showStatus("Nie udało się wczytać pliku", true);
    }
}
function goToRegex() {
    regexFound = findSuspicious(inputext, regexTest, regexReview);
    regexReview = regexFound.list;
    console.log("Regex - do sprawdzenia:", regexReview);
    showWords(regexList, regexReview);
    showStep(2);
}
function goToTrigram() {
    goodregex = buildText(regexFound);
    console.log("goodregex:", goodregex);
    trigramFound = findSuspicious(goodregex, trigramTest, checkReview);
    checkReview = trigramFound.list;
    console.log("Trigramy - do sprawdzenia:", checkReview);
    showWords(trigramList, checkReview);
    showStep(3);
}
async function goToResult() {
    trigood = buildText(trigramFound);
    console.log("trigood:", trigood);
    FinalResult = cleanSentences(trigood);
    console.log(
        "Sentences sent to PHP:",
        JSON.stringify(FinalResult, null, 2)
    );
    back3.disabled = true;
    next3.disabled = true;
    const data = await sendToPHP(FinalResult);
    back3.disabled = false;
    next3.disabled = false;
    if (data) {
        protocol = data;
        console.log("Protokół:", protocol);
        showProtocol(protocol);
        showSummary(protocol);
        showStep(4);
        showStatus(protocol.saved_file ? "Zapisano plik: " + protocol.saved_file : "");
    }
}
next1.addEventListener("click", goToRegex);
back2.addEventListener("click", () => showStep(1));
next2.addEventListener("click", goToTrigram);
back3.addEventListener("click", () => showStep(2));
next3.addEventListener("click", goToResult);
back4.addEventListener("click", () => showStep(3));
downloadButton.addEventListener("click", downloadProtocol);
browseButton.addEventListener("click", () => {
    fileInput.click();
});
fileInput.addEventListener("change", () => {
    const file = fileInput.files[0];
    importFile(file);
    fileInput.value = "";
});
dropZone.addEventListener("dragover", event => {
    event.preventDefault();
    dropZone.classList.add("dragover");
});
dropZone.addEventListener("dragleave", () => {
    dropZone.classList.remove("dragover");
});
dropZone.addEventListener("drop", event => {
    event.preventDefault();
    dropZone.classList.remove("dragover");
    const file = event.dataTransfer.files[0];
    importFile(file);
});
window.addEventListener("dragover", event => {
    event.preventDefault();
});
window.addEventListener("drop", event => {
    event.preventDefault();
});
