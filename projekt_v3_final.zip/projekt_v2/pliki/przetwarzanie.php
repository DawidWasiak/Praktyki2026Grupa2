<?php
set_time_limit(3600);
header("Content-Type: application/json; charset=utf-8");
function respond($data, $status = 200) {
    http_response_code($status);
    echo json_encode(
        $data,
        JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
    );
    exit;
}

// 1. Ustawienia z pliku ustawienia.txt
function parseSettings($text) {
    $out = [];
    $section = null;
    $listKey = null;
    foreach (preg_split('/\r?\n/', $text) as $raw) {
        $line = trim($raw);
        if ($line === "" || str_starts_with($line, "#")) continue;
        if (preg_match('/^\[(.+)\]$/u', $line, $m)) {
            $section = mb_strtolower(trim($m[1]));
            $out[$section] = [];
            $listKey = null;
            continue;
        }
        if ($section === null) continue;
        if (str_starts_with($line, "- ")) {
            if ($listKey !== null) {
                if (!is_array($out[$section][$listKey])) $out[$section][$listKey] = [];
                $out[$section][$listKey][] = trim(substr($line, 2));
            }
            continue;
        }
        $colon = strpos($line, ":");
        if ($colon === false) continue;
        $listKey = mb_strtolower(trim(substr($line, 0, $colon)));
        $out[$section][$listKey] = trim(substr($line, $colon + 1));
    }
    return $out;
}
function yes($value, $default = true) {
    if ($value === null || $value === "") return $default;
    return (bool)preg_match('/^(tak|true|1|yes|on)$/i', $value);
}
function num($value, $default) {
    $value = str_replace(",", ".", (string)$value);
    return is_numeric($value) ? $value + 0 : $default;
}
$settingsText = @file_get_contents(__DIR__ . "/ustawienia.txt");
if ($settingsText === false) {
    respond([
        "success" => false,
        "error" => "Nie można odczytać pliku ustawienia.txt"
    ], 500);
}
$settings = parseSettings($settingsText);
$S = $settings["llm_settings"] ?? [];
$llm = [
    "model" => ($S["model"] ?? "") !== "" ? $S["model"] : "qwen3:8b",
    "url" => ($S["url"] ?? "") !== "" ? $S["url"] : "http://127.0.0.1:11434/api/chat",
    "think" => yes($S["think"] ?? null, false),
    "temperature" => num($S["temperature"] ?? null, 0),
    "num_predict" => (int)num($S["num_predict"] ?? null, 2048),
    "num_ctx" => (int)num($S["num_ctx"] ?? null, 8192),
    "timeout_seconds" => (int)num($S["timeout_sekundy"] ?? null, 240),
    "repeat_penalty" => num($S["repeat_penalty"] ?? null, 1.1),
    "retries" => (int)num($S["ponowienia"] ?? null, 2)
];
$segmentation = [
    "markers" => is_array($S["nowy_punkt"] ?? null) ? $S["nowy_punkt"] : ["Przejdziemy teraz do"],
    "host_default" => ($S["prowadzacy_domyslnie"] ?? "") !== "" ? $S["prowadzacy_domyslnie"] : "Prowadzący",
    "host_names" => []
];
foreach (is_array($S["prowadzacy"] ?? null) ? $S["prowadzacy"] : [] as $item) {
    $pair = array_map("trim", explode("=>", $item, 2));
    if (count($pair) === 2) $segmentation["host_names"][] = ["pattern" => $pair[0], "name" => $pair[1]];
}
$output = [
    "save_json" => yes($S["zapisz_json"] ?? null, true),
    "folder" => ($S["folder_wynikow"] ?? "") !== "" ? $S["folder_wynikow"] : "wyniki",
    "protocol_title" => ($S["tytul_protokolu"] ?? "") !== "" ? $S["tytul_protokolu"] : "PROTOKÓŁ ZE SPOTKANIA"
];
set_time_limit((int)num($S["limit_calkowity_sekundy"] ?? null, 3600));
$useExample = yes($S["przyklad"] ?? null, true);
$titleFromModel = yes($S["tytul_z_modelu"] ?? null, false);

// Format odpowiedzi jest stały, bo PHP musi umieć go odczytać
const ANALYSIS_FORMAT = <<<'TXT'
Zwróć WYŁĄCZNIE poprawny JSON w tym formacie:
{
  "title": "tytuł punktu",
  "speakers": ["Dyrektor", "dr Nowak"],
  "topics": ["..."],
  "decisions": ["..."],
  "action_items": [ { "who": "dr Nowak", "task": "...", "deadline": "do końca dnia", "type": "polecenie" } ],
  "open_questions": ["..."]
}
Nie dodawaj komentarzy ani tekstu poza JSON-em.
TXT;
const PROTOCOL_FORMAT = <<<'TXT'
Zwróć WYŁĄCZNIE poprawny JSON w tym formacie:
{
  "title": "tytuł punktu",
  "entries": [
    { "speaker": "Dyrektor", "text": "Otworzył posiedzenie i przedstawił porządek obrad." }
  ]
}
Nie dodawaj komentarzy ani tekstu poza JSON-em.
TXT;
function stageFromSettings($section, $format) {
    return [
        "intro" => $section["rola"] ?? "",
        "rules" => is_array($section["zasady"] ?? null) ? $section["zasady"] : [],
        "format" => $format
    ];
}

// Przykład dla modelu (few-shot)
$example = [
    "enabled" => $useExample,
    "input" => <<<'TXT'
Prowadzący spotkanie: Prowadzący
Tytuł punktu: Informacje o finansowaniu

Fragment stenogramu:
Przejdziemy teraz do Informacje o finansowaniu. Udzielam głosu panu profesorowi Kowalskiemu.
Dziękuję za udzielenie głosu. Środki z subwencji nie pokrywają nawet kosztów utrzymania aparatury. Jeśli nie znajdziemy innych źródeł, nasz rozbój naukowy zostanie zahamowany.
Dziękuję panu profesorowi. Udzielam głosu doktorowi Nowakowi.
Dziękuję bardzo. Proponuję udział w krajowym korkusie grantowym, maksymalna kwota to pięć milionów złotych, wniosek trzeba złożyć do końca przyszłego miesiąca.
To brzmi obiecująco. Panie doktorze, proszę przesłać pełne informacje o konkursie na mój adres mailowy do końca dnia.
TXT,
    "analysis" => [
        "title" => "Informacje o finansowaniu",
        "speakers" => ["Prowadzący", "prof. Kowalski", "dr Nowak"],
        "topics" => ["niedostateczne finansowanie z subwencji", "krajowy konkurs grantowy"],
        "decisions" => [],
        "action_items" => [
            ["who" => "dr Nowak", "task" => "Przesłać prowadzącemu pełne informacje o konkursie grantowym na adres e-mail", "deadline" => "do końca dnia", "type" => "polecenie"]
        ],
        "open_questions" => ["Skąd pozyskać dodatkowe źródła finansowania utrzymania aparatury?"]
    ],
    "protocol" => [
        "title" => "Informacje o finansowaniu",
        "entries" => [
            ["speaker" => "prof. Kowalski", "text" => "Przedstawił niedostateczne finansowanie jednostki: środki z subwencji nie pokrywają kosztów utrzymania aparatury, a bez nowych źródeł rozwój naukowy zostanie zahamowany."],
            ["speaker" => "dr Nowak", "text" => "Zaproponował udział w krajowym konkursie grantowym (do 5 mln zł, wniosek do końca przyszłego miesiąca)."],
            ["speaker" => "Prowadzący", "text" => "Zobowiązał dr. Nowaka do przesłania pełnych informacji o konkursie na swój adres e-mail do końca dnia."]
        ]
    ]
];

// 2. Odczyt danych z JavaScript
$input = file_get_contents("php://input");
$data = json_decode($input, true);
if (
    !is_array($data) ||
    !isset($data["sentences"]) ||
    !is_array($data["sentences"])
) {
    respond([
        "success" => false,
        "error" => "Nieprawidłowe dane wejściowe"
    ], 400);
}
$sentences = array_values(array_filter(
    $data["sentences"],
    fn($s) => is_string($s) && trim($s) !== ""
));
$text = implode("\n", $sentences);
if (trim($text) === "") {
    respond([
        "success" => false,
        "error" => "Brak tekstu do analizy"
    ], 400);
}

// 3. Prompt = intro + ponumerowane zasady + format
function buildPrompt($stage) {
    $prompt = trim($stage["intro"] ?? "");
    $rules = $stage["rules"] ?? [];
    if (count($rules) > 0) {
        $prompt .= "\n\nZasady:";
        foreach (array_values($rules) as $i => $rule) {
            $prompt .= "\n" . ($i + 1) . ". " . $rule;
        }
    }
    $prompt .= "\n\n" . trim($stage["format"] ?? "Zwróć wyłącznie poprawny JSON.");
    return $prompt;
}
$analysisStage = stageFromSettings($settings["llm_krok1_analiza"] ?? [], ANALYSIS_FORMAT);
$analysisPrompt = buildPrompt($analysisStage);
$protocolStage = stageFromSettings($settings["llm_krok2_protokol"] ?? [], PROTOCOL_FORMAT);
$protocolPrompt = buildPrompt($protocolStage);

function toJson($value) {
    return json_encode($value, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_INVALID_UTF8_SUBSTITUTE);
}

// 4. Zapytanie do Ollama. LLM zwraca JSON jako TEKST, a PHP zamienia go na tablicę.
function askOllamaOnce($llm, $systemPrompt, $exampleMessages, $userPrompt) {
    $messages = [["role" => "system", "content" => $systemPrompt]];
    foreach ($exampleMessages as $message) {
        $messages[] = $message;
    }
    $messages[] = ["role" => "user", "content" => $userPrompt];
    $payload = [
        "model" => $llm["model"] ?? "qwen3:8b",
        "stream" => false,
        "think" => (bool)($llm["think"] ?? false),
        "format" => "json",
        "messages" => $messages,
        "options" => [
            "temperature" => $llm["temperature"] ?? 0,
            "num_predict" => $llm["num_predict"] ?? 2048,
            "num_ctx" => $llm["num_ctx"] ?? 8192,
            "repeat_penalty" => $llm["repeat_penalty"] ?? 1.1
        ]
    ];
    $send = function ($payload) use ($llm) {
        $ch = curl_init($llm["url"] ?? "http://127.0.0.1:11434/api/chat");
        curl_setopt_array($ch, [CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                "Content-Type: application/json"
            ],
            CURLOPT_POSTFIELDS => json_encode(
                $payload,
                JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
            ),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => $llm["timeout_seconds"] ?? 240
        ]);
        $response = curl_exec($ch);
        $result = [$response, curl_error($ch), curl_getinfo($ch, CURLINFO_HTTP_CODE)];
        curl_close($ch);
        return $result;
    };
    [$response, $error, $status] = $send($payload);
    // Model bez trybu "think" (np. Bielik) - powtórz zapytanie bez tego parametru
    if ($status === 400 && is_string($response) && stripos($response, "think") !== false) {
        unset($payload["think"]);
        [$response, $error, $status] = $send($payload);
    }
    if ($response === false) {
        respond([
            "success" => false,
            "error" => "Nie można połączyć się z Ollama: " . $error
        ], 502);
    }
    if ($status !== 200) {
        respond([
            "success" => false,
            "error" => "Ollama zwróciła HTTP " . $status,
            "details" => $response
        ], 502);
    }
    $ollama = json_decode($response, true);
    $content = $ollama["message"]["content"] ?? "";
    $result = json_decode($content, true);
    return [is_array($result) ? $result : null, $content];
}

// Zapytanie z ponowieniem: gdy model zwróci zepsuty JSON (np. zapętli się),
// pytamy jeszcze raz z wyższą temperaturą i karą za powtórzenia
function askOllama($llm, $systemPrompt, $exampleMessages, $userPrompt) {
    $attempts = 1 + max(0, (int)($llm["retries"] ?? 2));
    $content = "";
    for ($i = 0; $i < $attempts; $i++) {
        $try = $llm;
        $try["temperature"] = ($llm["temperature"] ?? 0) + 0.3 * $i;
        $try["repeat_penalty"] = ($llm["repeat_penalty"] ?? 1.1) + 0.1 * $i;
        [$result, $content] = askOllamaOnce($try, $systemPrompt, $exampleMessages, $userPrompt);
        if ($result !== null) return $result;
    }
    respond([
        "success" => false,
        "error" => "Nieprawidłowa odpowiedź modelu (po " . $attempts . " próbach). Spróbuj większego modelu albo zwiększ repeat_penalty.",
        "details" => mb_substr($content, 0, 2000)
    ], 502);
}

// Pomocnicze: porządkowanie odpowiedzi modelu
function stringList($value) {
    if (!is_array($value)) return [];
    $list = [];
    foreach ($value as $item) {
        $item = trim(is_string($item) ? $item : (string)json_encode($item, JSON_UNESCAPED_UNICODE));
        if ($item !== "" && !in_array(mb_strtolower($item), array_map("mb_strtolower", $list))) $list[] = $item;
    }
    return $list;
}
function cleanAnalysis($result) {
    $actions = [];
    foreach ($result["action_items"] ?? [] as $item) {
        if (!is_array($item)) continue;
        $task = trim((string)($item["task"] ?? ""));
        if ($task === "") continue;
        $who = trim((string)($item["who"] ?? ""));
        $deadline = trim((string)($item["deadline"] ?? ""));
        $type = mb_strtolower(trim((string)($item["type"] ?? "")));
        $actions[] = [
            "type" => str_starts_with($type, "deklar") ? "deklaracja" : "polecenie",
            "who" => $who === "" ? null : $who,
            "task" => $task,
            "deadline" => ($deadline === "" || strtolower($deadline) === "null") ? null : $deadline
        ];
    }
    return [
        "title" => trim((string)($result["title"] ?? "")),
        "speakers" => stringList($result["speakers"] ?? []),
        "topics" => stringList($result["topics"] ?? []),
        "decisions" => stringList($result["decisions"] ?? []),
        "action_items" => $actions,
        "open_questions" => stringList($result["open_questions"] ?? [])
    ];
}

// Przykłady (few-shot) dla obu kroków
$analysisExample = [];
$protocolExample = [];
if (!empty($example["enabled"])) {
    $analysisExample = [
        ["role" => "user", "content" => $example["input"]],
        ["role" => "assistant", "content" => toJson($example["analysis"])]
    ];
    $protocolExample = [
        ["role" => "user", "content" => $example["input"] . "\n\nAnaliza (krok 1):\n" . toJson($example["analysis"])],
        ["role" => "assistant", "content" => toJson($example["protocol"])]
    ];
}

// Poprawki po LLM: "regex => zamiana" z sekcji [poprawki_po_llm]
$fixes = [];
foreach (is_array($settings["poprawki_po_llm"]["zamiany"] ?? null) ? $settings["poprawki_po_llm"]["zamiany"] : [] as $item) {
    $pair = explode("=>", $item, 2);
    $pattern = '~' . str_replace('~', '\~', trim($pair[0])) . '~iu';
    if (trim($pair[0]) === "" || @preg_match($pattern, "") === false) continue;
    $fixes[] = [$pattern, trim($pair[1] ?? "")];
}
function fixText($text, $fixes) {
    foreach ($fixes as [$pattern, $replacement]) {
        $new = preg_replace($pattern, $replacement, $text);
        if ($new !== null) $text = $new;
    }
    $text = preg_replace('/\s{2,}/u', ' ', $text);
    $text = trim($text);
    // wielka litera na początku
    return mb_strtoupper(mb_substr($text, 0, 1)) . mb_substr($text, 1);
}

// 5. Podział stenogramu na punkty obrad
$markers = $segmentation["markers"] ?? ["Przejdziemy teraz do"];
$marker = '(?:' . implode('|', $markers) . ')';
$parts = preg_split('/(?=' . $marker . ')/iu', $text);
if ($parts === false) {
    respond(["success" => false, "error" => "Błędny regex w segmentation.markers"], 500);
}
$parts = array_values(array_filter($parts, fn($p) => trim($p) !== ""));
if (count($parts) > 1 && !preg_match('/^' . $marker . '/iu', $parts[0])) {
    $parts[1] = $parts[0] . "\n" . $parts[1];
    array_shift($parts);
}

$host = $segmentation["host_default"] ?? "Prowadzący";
foreach ($segmentation["host_names"] ?? [] as $rule) {
    if (preg_match('/' . $rule["pattern"] . '/iu', $text)) {
        $host = $rule["name"];
        break;
    }
}

// 6. Dla każdego punktu: KROK 1 (analiza) -> KROK 2 (protokół)
$points = [];
$summary = ["topics" => [], "decisions" => [], "action_items" => [], "open_questions" => []];
foreach ($parts as $part) {
    $title = "";
    if (preg_match('/' . $marker . '\s+(?:punktu:?\s*)?([^.!?\n]+)/iu', $part, $m)) {
        $title = trim($m[1]);
    }
    $header = "Prowadzący spotkanie: " . $host
        . "\nTytuł punktu: " . ($title === "" ? "(nieznany)" : $title)
        . "\n\nFragment stenogramu:\n" . $part;

    // KROK 1: tematy, decyzje, zadania, otwarte pytania
    $analysis = cleanAnalysis(askOllama($llm, $analysisPrompt, $analysisExample, $header));

    // KROK 2: wpisy protokołu na podstawie analizy
    $result = askOllama($llm, $protocolPrompt, $protocolExample,
        $header . "\n\nAnaliza (krok 1):\n" . toJson($analysis));

    $entries = [];
    foreach ($result["entries"] ?? [] as $entry) {
        if (!is_array($entry)) continue;
        $speaker = trim((string)($entry["speaker"] ?? ""));
        $entryText = fixText(trim((string)($entry["text"] ?? "")), $fixes);
        if ($entryText === "") {
            continue;
        }
        $last = count($entries) - 1;
        if ($last >= 0 && ($speaker === "" || $entries[$last]["speaker"] === $speaker)) {
            $entries[$last]["text"] .= " " . $entryText;
            continue;
        }
        $entries[] = [
            "speaker" => $speaker === "" ? null : $speaker,
            "text" => $entryText
        ];
    }
    // Tytuł: domyślnie ze stenogramu (sprawdzony przez człowieka), opcjonalnie z modelu
    $modelTitle = trim((string)($result["title"] ?? ""));
    if ($modelTitle === "") $modelTitle = $analysis["title"];
    $pointTitle = $titleFromModel
        ? ($modelTitle !== "" ? $modelTitle : $title)
        : ($title !== "" ? $title : $modelTitle);
    if ($pointTitle === "") $pointTitle = "Punkt " . (count($points) + 1);
    $points[] = [
        "title" => $pointTitle,
        "entries" => $entries,
        "analysis" => $analysis
    ];

    // Podsumowanie w kolejności punktów obrad (nr = numer punktu w protokole)
    $nr = count($points);
    foreach ($analysis["topics"] as $t) $summary["topics"][] = ["nr" => $nr, "point" => $pointTitle, "text" => $t];
    foreach ($analysis["decisions"] as $d) $summary["decisions"][] = ["nr" => $nr, "point" => $pointTitle, "text" => $d];
    foreach ($analysis["action_items"] as $a) $summary["action_items"][] = ["nr" => $nr, "point" => $pointTitle] + $a;
    foreach ($analysis["open_questions"] as $q) $summary["open_questions"][] = ["nr" => $nr, "point" => $pointTitle, "text" => $q];
}

$protocol = [
    "success" => true,
    "title" => $output["protocol_title"] ?? "PROTOKÓŁ ZE SPOTKANIA",
    "date" => date("Y-m-d H:i"),
    "model" => $llm["model"] ?? "qwen3:8b",
    "host" => $host,
    "points" => $points,
    "summary" => $summary
];

// 7. Zapis protokołu do pliku .json
if (!empty($output["save_json"])) {
    $folder = __DIR__ . "/" . trim($output["folder"] ?? "wyniki", "/\\");
    if (!is_dir($folder)) @mkdir($folder, 0777, true);
    $fileName = "protokol_" . date("Y-m-d_H-i-s") . ".json";
    if (@file_put_contents($folder . "/" . $fileName, toJson($protocol)) !== false) {
        $protocol["saved_file"] = basename($folder) . "/" . $fileName;
    }
}

respond($protocol);
